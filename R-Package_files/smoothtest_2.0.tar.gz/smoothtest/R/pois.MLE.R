`pois.MLE` <-
function(sample){
  lambda<-mean(sample)
  return(lambda)
}

